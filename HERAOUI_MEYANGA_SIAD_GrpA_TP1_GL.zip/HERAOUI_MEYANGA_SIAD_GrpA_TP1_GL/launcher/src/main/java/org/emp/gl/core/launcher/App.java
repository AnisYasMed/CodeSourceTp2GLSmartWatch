package org.emp.gl.core.launcher;

import org.emp.gl.console.impl.CompteARebour;
import org.emp.gl.core.lookup.Lookup;
import org.emp.gl.gui.impl.FirstGuiTimer;
import org.emp.gl.gui.impl.IFirstGui;
import org.emp.gl.gui.impl.SecondGuiTimer;
import org.emp.gl.iactions.IConfigAction;
import org.emp.gl.iactions.IIncrementAction;
import org.emp.gl.iactions.IModeAction;
import org.emp.gl.timer.service.TimerChangeListener;
import org.emp.gl.timer.service.TimerService;
import org.emp.gl.timer.service.impl.withdelegation.TimerServiceImplWithDelegation;
import org.emp.gl.model.WatchEngine;


public class App {

    static {
        Lookup.getInstance().register(TimerService.class, new TimerServiceImplWithDelegation());
    }

    public static void main(String[] args) {

        TimerService timer = Lookup.getInstance().getService(TimerService.class);
        FirstGuiTimer guiTimer = new FirstGuiTimer();
      
        Lookup.getInstance().register(TimerChangeListener.class, guiTimer); 
        Lookup.getInstance().register(IFirstGui.class, guiTimer);     
        TimerChangeListener guiObserver = (TimerChangeListener) Lookup.getInstance().getService(TimerChangeListener.class);
        timer.addTimeChangeListener(guiObserver);
        WatchEngine myWatch = new WatchEngine();
        Lookup.getInstance().register( IConfigAction.class , myWatch);
        Lookup.getInstance().register( IModeAction.class , myWatch);
        Lookup.getInstance().register( IIncrementAction.class , myWatch);
        SecondGuiTimer guiConfig = new SecondGuiTimer();
        
        System.out.println("Count down to 5 starts : ");
        for( int compteur=0 ; compteur<3 ; compteur++)
        {
             timer.addTimeChangeListener(new CompteARebour(5) );
        }
    }

}
