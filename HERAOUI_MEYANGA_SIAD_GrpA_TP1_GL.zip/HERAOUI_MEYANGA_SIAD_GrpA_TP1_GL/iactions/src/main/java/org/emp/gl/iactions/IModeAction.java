
package org.emp.gl.iactions;


public interface IModeAction {
    
    public void doModeAction();
    
}
