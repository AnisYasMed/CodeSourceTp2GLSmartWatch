
package org.emp.gl.iactions;


public interface IIncrementAction {
    
    public void doIncrementAction();
    
}
