
package org.emp.gl.iactions;


public interface IConfigAction {
    
    public void doConfigAction();
    
}
