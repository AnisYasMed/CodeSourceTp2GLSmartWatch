
package org.emp.gl.model;


public class InitState extends GuiTimerState{
    
    public InitState(WatchEngine sgt)  {
        super(sgt);
    }
      
    @Override
    public void config()
    {
        sTimer.setState( new SecondState(sTimer));
        System.out.println("Init state to Second state ");
    }
         
}
