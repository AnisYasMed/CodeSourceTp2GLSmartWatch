
package org.emp.gl.model;

import org.emp.gl.core.lookup.Lookup;
import org.emp.gl.gui.impl.IFirstGui;
import org.emp.gl.iactions.IConfigAction;
import org.emp.gl.iactions.IIncrementAction;
import org.emp.gl.iactions.IModeAction;
import org.emp.gl.timer.service.impl.withdelegation.TimerServiceImplWithDelegation;

public class WatchEngine extends TimerServiceImplWithDelegation implements IModeAction , IIncrementAction , IConfigAction {
    
    public GuiTimerState state = new InitState(this);
        
    
    public void setState(GuiTimerState s) 
    {  
        this.state=s;
    }
    
    @Override
    public void doModeAction() {
       
        state.mode();
    }

    @Override
     public void doIncrementAction() {
        IFirstGui fGui = Lookup.getInstance().getService(IFirstGui.class);
        int addH = fGui.getterAddHour();
        int addM = fGui.getterAddMinute();
        int addS = fGui.getterAddSecond();
        if(state.getClass()==HourState.class)
        {
           addH++;
           fGui.setterAddHour(addH);
        }
        if(state.getClass()==MinuteState.class)
        {
           addM++;
           fGui.setterAddMinute(addM);
        }
        if(state.getClass()==SecondState.class)
        {
           addS++;
           fGui.setterAddSeconde(addS);
        }
    }
     
    @Override
    public void doConfigAction() {
        state.config();
    }
    
    @Override
    public int getMinutes() {
        return super.getMinutes();
    }

    @Override
    public int getHeures() {
        return super.getHeures();
    }

    @Override
    public int getSecondes() {
        return  super.getSecondes();
    }

    @Override
    public int getDixiemeDeSeconde() {
        return super.getDixiemeDeSeconde();
    }
    
}
