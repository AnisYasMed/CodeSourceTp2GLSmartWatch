
package org.emp.gl.model;


public abstract class GuiTimerState {

    final WatchEngine sTimer;
 
    public GuiTimerState( WatchEngine sgt) {
        if(sgt== null)
        {
            System.out.println("SecondGuiTimer n'est pas instanciée ! ");
            sTimer=null;
        }
        else
        {
            this.sTimer=sgt; 
        }
    }

    public void mode() {}
    
    public void config() {}
    
}

