
package org.emp.gl.model;


public class MinuteState extends GuiTimerState{
 
    public MinuteState(WatchEngine sgt) {
        super(sgt);
    }
  
    @Override
    public void mode()
    {
        sTimer.setState( new HourState(sTimer));
        System.out.println("Minute state to Hour state ");
    }
    
    @Override
    public void config()
    {
        sTimer.setState( new InitState(sTimer));
        System.out.println("Minute state to Init state");
    }
}
