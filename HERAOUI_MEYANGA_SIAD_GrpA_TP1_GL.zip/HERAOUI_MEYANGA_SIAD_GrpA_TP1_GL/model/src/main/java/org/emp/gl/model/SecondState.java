
package org.emp.gl.model;


public class SecondState extends GuiTimerState{
  
  
    public SecondState(WatchEngine sgt) {
        super(sgt);
    }
    
    @Override
    public void mode()
    {
        sTimer.setState( new MinuteState(sTimer));
        System.out.println("Second state to Minute state");
    }
    
    @Override
    public void config()
    {
        sTimer.setState( new InitState(sTimer));
        System.out.println("Second state to Init state");
    }
    
}
