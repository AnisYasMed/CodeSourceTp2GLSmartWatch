
package org.emp.gl.model;


public class HourState extends GuiTimerState{
    
    public HourState(WatchEngine sgt)  {
        super(sgt);
    }
    
    @Override
    public void mode()
    {
        sTimer.setState( new SecondState(sTimer));
        System.out.println("Hour state to Second state");
    }
    
    @Override
    public void config()
    {
        sTimer.setState( new InitState(sTimer));
        System.out.println("Hour state to Init state");
    }
    
}
