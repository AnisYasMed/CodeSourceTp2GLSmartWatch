package org.emp.gl.console.impl;

import java.beans.PropertyChangeEvent;
import org.emp.gl.core.lookup.Lookup;
import org.emp.gl.timer.service.TimerChangeListener;
import org.emp.gl.timer.service.TimerService;

public class AfficheurHeureSurConsole implements TimerChangeListener {

    public void afficheur() {
        TimerService ts = Lookup.getInstance().getService(TimerService.class);    
        System.out.println("" + ts.getHeures() + ":" + ts.getMinutes() + ":"
                + ts.getSecondes() + "," + ts.getDixiemeDeSeconde());
    }
    
    @Override
    public void propertyChange(PropertyChangeEvent pce) {
        afficheur();
    }

}