
package org.emp.gl.console.impl;

import java.beans.PropertyChangeEvent;
import org.emp.gl.core.lookup.Lookup;
import org.emp.gl.timer.service.TimerChangeListener;
import org.emp.gl.timer.service.TimerService;


public class CompteARebour implements TimerChangeListener {

    private int compteArebours;

    public CompteARebour(int compteARebour) {
        this.compteArebours = compteARebour ;
    }

    
    public void compteur() {
         compteArebours--;
         System.out.println("Il me reste : " + compteArebours);
        if (compteArebours == 0)
        { 
            Lookup.getInstance().getService(TimerService.class).removeTimeChangeListener(this);
        }
    }

    @Override
    public void propertyChange(PropertyChangeEvent pce) {
         compteur();    
    }
    
}
