
package org.emp.gl.gui.impl;

public interface IFirstGui {
    
    public int getterAddHour();
    public int getterAddMinute();
    public int getterAddSecond();
    public void setterAddHour(int f);
    public void setterAddMinute(int f);
    public void setterAddSeconde(int f);

    
}
