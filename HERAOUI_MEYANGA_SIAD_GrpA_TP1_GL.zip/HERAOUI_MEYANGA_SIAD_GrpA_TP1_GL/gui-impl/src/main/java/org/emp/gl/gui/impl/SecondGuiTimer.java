package org.emp.gl.gui.impl;

import org.emp.gl.core.lookup.Lookup;
import org.emp.gl.iactions.IConfigAction;
import org.emp.gl.iactions.IIncrementAction;
import org.emp.gl.iactions.IModeAction;


public class SecondGuiTimer extends javax.swing.JFrame  {

    public SecondGuiTimer() {
        initComponents();
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible( true );
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        container = new javax.swing.JPanel();
        jLayeredPane1 = new javax.swing.JLayeredPane();
        config = new javax.swing.JButton();
        mode = new javax.swing.JButton();
        increment = new javax.swing.JButton();
        labelPanel = new javax.swing.JPanel();
        smartWatch = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        java.awt.GridBagLayout containerLayout = new java.awt.GridBagLayout();
        containerLayout.columnWidths = new int[] {0, 50, 0, 50, 0, 50, 0, 50, 0, 50, 0, 50, 0};
        containerLayout.rowHeights = new int[] {0, 50, 0, 50, 0, 50, 0, 50, 0};
        containerLayout.columnWeights = new double[] {200.5};
        containerLayout.rowWeights = new double[] {200.3};
        container.setLayout(containerLayout);
        getContentPane().add(container, java.awt.BorderLayout.CENTER);

        jLayeredPane1.setLayout(new java.awt.GridLayout(1, 0));

        config.setBackground(new java.awt.Color(51, 102, 255));
        config.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        config.setText("Config");
        config.setToolTipText("");
        config.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                configActionPerformed(evt);
            }
        });
        jLayeredPane1.add(config);

        mode.setBackground(new java.awt.Color(51, 102, 255));
        mode.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        mode.setText("Mode");
        mode.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modeActionPerformed(evt);
            }
        });
        jLayeredPane1.add(mode);

        increment.setBackground(new java.awt.Color(51, 102, 255));
        increment.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        increment.setText("Increment");
        increment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                incrementActionPerformed(evt);
            }
        });
        jLayeredPane1.add(increment);

        getContentPane().add(jLayeredPane1, java.awt.BorderLayout.PAGE_START);

        labelPanel.setLayout(new java.awt.GridBagLayout());

        smartWatch.setBackground(new java.awt.Color(51, 102, 255));
        smartWatch.setFont(new java.awt.Font("Tahoma", 1, 22)); // NOI18N
        smartWatch.setForeground(new java.awt.Color(51, 102, 255));
        smartWatch.setText("TIME CONFIGURATION");
        labelPanel.add(smartWatch, new java.awt.GridBagConstraints());

        getContentPane().add(labelPanel, java.awt.BorderLayout.PAGE_END);

        setBounds(240, 240, 400, 300);
    }// </editor-fold>//GEN-END:initComponents

    private void modeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modeActionPerformed

     IModeAction ima= Lookup.getInstance().getService(IModeAction.class);
     ima.doModeAction();
     
    }//GEN-LAST:event_modeActionPerformed

    private void incrementActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_incrementActionPerformed

     IIncrementAction iia= Lookup.getInstance().getService(IIncrementAction.class);
     iia.doIncrementAction();
      
    }//GEN-LAST:event_incrementActionPerformed

    private void configActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_configActionPerformed
        
     IConfigAction ica= Lookup.getInstance().getService(IConfigAction.class);
     ica.doConfigAction();
     
    }//GEN-LAST:event_configActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton config;
    private javax.swing.JPanel container;
    private javax.swing.JButton increment;
    private javax.swing.JLayeredPane jLayeredPane1;
    private javax.swing.JPanel labelPanel;
    private javax.swing.JButton mode;
    private javax.swing.JLabel smartWatch;
    // End of variables declaration//GEN-END:variables

}
