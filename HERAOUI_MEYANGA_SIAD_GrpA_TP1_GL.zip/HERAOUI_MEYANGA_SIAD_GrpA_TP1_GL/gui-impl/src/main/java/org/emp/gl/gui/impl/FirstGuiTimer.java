package org.emp.gl.gui.impl;

import java.beans.PropertyChangeEvent;
import org.emp.gl.core.lookup.Lookup;
import org.emp.gl.timer.service.TimerChangeListener;
import org.emp.gl.timer.service.TimerService;

       

public class FirstGuiTimer extends javax.swing.JFrame implements  TimerChangeListener , IFirstGui {
    
    int dixieme=0;
    int seconde = 0;
    int minute = 0;
    int heure = 0;
    
    int addOneHour=0;
    int addOneMinute=0;
    int addOneSecond=0;


    public FirstGuiTimer() {
        initComponents();
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible( true );
    }

    public void timeChanged() {
        TimerService a = Lookup.getInstance().getService(TimerService.class);
        heure = a.getHeures();
        minute = a.getMinutes();
        seconde = a.getSecondes();
        dixieme = a.getDixiemeDeSeconde();
        times.setText((heure+addOneHour)%24 + ":" + (minute+addOneMinute)%60 + ":" + (seconde+addOneSecond)%60  + ":" + dixieme);
    }

     @Override
     public void propertyChange(PropertyChangeEvent pce) {
        timeChanged();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        container = new javax.swing.JPanel();
        times = new javax.swing.JLabel();
        labelContainer = new javax.swing.JPanel();
        firstGui = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        container.setLayout(new java.awt.GridBagLayout());

        times.setBackground(new java.awt.Color(0, 102, 204));
        times.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        times.setForeground(new java.awt.Color(0, 51, 204));
        times.setText("00:00:00");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 13;
        gridBagConstraints.gridwidth = 14;
        gridBagConstraints.ipadx = 100;
        gridBagConstraints.ipady = 100;
        gridBagConstraints.weightx = 10.0;
        gridBagConstraints.weighty = 10.0;
        gridBagConstraints.insets = new java.awt.Insets(10, 95, 13, 8);
        container.add(times, gridBagConstraints);

        getContentPane().add(container, java.awt.BorderLayout.CENTER);

        labelContainer.setLayout(new java.awt.GridBagLayout());

        firstGui.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        firstGui.setForeground(new java.awt.Color(0, 51, 204));
        firstGui.setText("SMART WATCH");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.insets = new java.awt.Insets(10, 15, 0, 0);
        labelContainer.add(firstGui, gridBagConstraints);

        getContentPane().add(labelContainer, java.awt.BorderLayout.PAGE_START);

        pack();
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel container;
    private javax.swing.JLabel firstGui;
    private javax.swing.JPanel labelContainer;
    private javax.swing.JLabel times;
    // End of variables declaration//GEN-END:variables

    @Override
    public int getterAddHour() {
      return this.addOneHour;
    }

    @Override
    public int getterAddMinute() {
       return this.addOneMinute;
    }

    @Override
    public int getterAddSecond() {
         return this.addOneSecond;
    }

    @Override
    public void setterAddHour(int f) {
        this.addOneHour=f;
    }

    @Override
    public void setterAddMinute(int f) {
         this.addOneMinute=f;
    }

    @Override
    public void setterAddSeconde(int f) {
      this.addOneSecond=f;
    }

 
}
